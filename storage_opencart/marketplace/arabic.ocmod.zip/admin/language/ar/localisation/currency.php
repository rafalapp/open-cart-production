<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']        = 'العملات';

// Text
$_['text_success']         = 'تم التعديل!';
$_['text_list']               = 'قائمة';
$_['text_add']                = 'ادراج';
$_['text_edit']               = 'تحرير';
$_['text_iso']             = 'يمكنك الوصول الى كامل قائمة رموز الايزو للعملات من خلال هذا <a href="http://www.xe.com/iso4217.php" target="_blank" class="alert-link">الرابط</a>.';

// Column
$_['column_title']         = 'عنوان العملة';
$_['column_code']          = 'الرمز';
$_['column_value']         = 'القيمة';
$_['column_status']        = 'الحالة';
$_['column_date_modified'] = 'اخر تحديث';
$_['column_action']        = 'تحرير';

// Entry
$_['entry_title']          = 'عنوان العملة';
$_['entry_code']           = 'الرمز العالمي للعملة. لا تقم بتغييرها اذا كانت هذه هي العملة الافتراضية، وتغييرها سوف يسبب مشاكل في المتجر.';
$_['entry_value']          = 'القيمة';
$_['entry_symbol_left']    = 'الرمز على اليمين';
$_['entry_symbol_right']   = 'الرمز على اليسار';
$_['entry_decimal_place']  = 'القيمة العشرية';
$_['entry_status']         = 'الحالة';

// Help
$_['help_code']            = 'لا تقم بتغييرها اذا كانت هذه هي العملة الافتراضية للمتجر وتغييرها سوف يسبب مشاكل في المتجر.';
$_['help_value']           = 'ضع القيمة 1.00000 اذا كانت هذه هي العملة الافتراضية.';

// Error
$_['error_permission']     = 'تحذير: أنت لا تمتلك صلاحيات التعديل!';
$_['error_extension']      = 'تحذير: لم يتم العثور على موديول العملة!';
$_['error_title']          = 'العنوان يجب أن يكون بين 3 و 32 رمزاً!';
$_['error_code']           = 'رمز العملة يجب أن يحتوي على 3 رمزاً!';
$_['error_default']        = 'تحذير: لايمكن حذف العملة الافتراضية!';
$_['error_store']          = 'تحذير: لا يمكن حذف هذه العملة لأنها مرتبطة مع %s متاجر!';
$_['error_order']          = 'تحذير: لا يمكن حذف هذه العملة لأنها مرتبطة مع %s طلبات!';
