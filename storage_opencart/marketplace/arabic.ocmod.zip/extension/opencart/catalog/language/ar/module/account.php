<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']     = 'الحساب';

// Text
$_['text_register']     = 'تسجيل';
$_['text_login']        = 'دخول';
$_['text_logout']       = 'خروج';
$_['text_forgotten']    = 'نسيت كلمة المرور';
$_['text_account']      = 'حسابي';
$_['text_edit']         = 'تحرير الحساب';
$_['text_password']     = 'كلمة المرور';
$_['text_address']      = 'دفتر العناويين';
$_['text_wishlist']     = 'مفضلتي';
$_['text_order']        = 'طلباتي';
$_['text_download']     = 'الملفات الرقمية';
$_['text_reward']       = 'نقاط المكافآت';
$_['text_return']       = 'الإستبدال والاسترجاع';
$_['text_transaction']  = 'رصيدي';
$_['text_newsletter']   = 'القائمة البريدية';
$_['text_subscription'] = 'خطة الاشتراك';
